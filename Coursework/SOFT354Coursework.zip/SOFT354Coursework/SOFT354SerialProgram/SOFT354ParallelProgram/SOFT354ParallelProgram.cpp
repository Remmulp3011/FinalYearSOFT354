// SOFT354SerialProgram.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <sqlite3.h>
#include <iostream>
#include <stdlib.h>
#include <vector>

using namespace std;
//TO keep console open to see prints use fn+ctrl+F5

//typedef int(*sqlite3_callback)(
//	void*,    /* Data provided in the 4th argument of sqlite3_exec() */
//	int,      /* The number of columns in row */
//	char**,   /* An array of strings representing fields in the row */
//	char**    /* An array of strings representing column names */
//	);

//Callback to run the queries. See above for the paramaters this takes
static int callback(void *NotUsed, int argc, char **argv, char **azColName) {
	int i;
	for (i = 0; i<argc; i++) {
		printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
	}
	printf("\n");
	return 0;
}

int main(int argc, char* argv[])
{
	/*CHANGE THE textToFind VALUE TO CHANGE WHAT IT IS THAT IS TO BE CHECKED FOR IN THE TABLE! NOTE: it is not case sensitive*/
	string textToFind = "parallel";

	string textToBeSearched;
	sqlite3 *db;
	char *zErrMsg = 0;
	int rc;
	char *tableExist;
	char *getAllRecords;
	char *createSql;
	char *insertSql;
	char *selectSql;
	char *updateIsPresentColumn;
	const char* data = "Callback function called"; //Used in the select SQL exec()
	sqlite3_stmt * stmt;
	sqlite3_stmt * stmtSearch;
	sqlite3_stmt * stmtUpdate;
	std::vector< std::vector < std::string > > result; //Create vectors of vectors, this is used to store the return of the select SQL as it returns as columns and rows
	std::vector< std::vector < std::string > > resultSearch; //Create vectors of vectors, this is used to store the return of the select SQL as it returns as columns and rows
	int idToUpdate;

	//Create the size of the vectors as you know number of columns (this case one due to the select count(type)). Need to set the same number below or you will get NULL exception
	for (int i = 0; i < 1; i++)
		result.push_back(std::vector< std::string >());

	//Check connection is valid
	if (sqlite3_open("SOFT354Coursework.db", &db) == SQLITE_OK)
	{
		//Query to see if the table has already been created will return 0 if not and 1 if it has
		tableExist = "select count(type) from sqlite_master where type = 'table' and name = 'TEXT_TO_BE_SEARCHED';";
		sqlite3_prepare(db, tableExist, -1, &stmt, NULL);//preparing the statement
		sqlite3_step(stmt); //executing the statement

		while (sqlite3_column_text(stmt, 0))
		{
			//Loop through the results and store them, 1 due to the fact that ther is 1 column. 
			//You will always know the number of columns but not rows.
			for (int i = 0; i < 1; i++)
				result[i].push_back(std::string((char *)sqlite3_column_text(stmt, i)));
			sqlite3_step(stmt);
		}

		//Access the first row and first column of the vectors which is were the result is stored.
		std::string resultOfExistTable = result[0][0];
		sqlite3_finalize(stmt);
		//If not, create and populate
		if (resultOfExistTable == "0")
		{
			printf("Table TEXT_TO_BE_SEARCHED does not exsist, creating table...\n");
			/* Create SQL statement */
			createSql = "CREATE TABLE TEXT_TO_BE_SEARCHED("  \
				"ID INT PRIMARY KEY     NOT NULL," \
				"TEXT_TO_SEARCH         TEXT    NOT NULL," \
				"IS_PRESENT             INT);";

			/* Execute CREATE SQL */
			rc = sqlite3_exec(db, createSql, callback, 0, &zErrMsg);
			if (rc != SQLITE_OK) {
				fprintf(stderr, "SQL error: %s\n", zErrMsg);
				sqlite3_free(zErrMsg);
			}
			else {
				fprintf(stdout, "Table created successfully\n");
			}

			/* INSERT SQL statement*/
			printf("Populating TEXT_TO_BE_SEARCHED with intial data...\n");

			insertSql = "INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH) "  \
				"VALUES (1, 'Parallel computing is a type of computation in which many calculations or the execution of processes are carried out simultaneously. Large problems can often be divided into smaller ones, which can then be solved at the same time. There are several different forms of parallel computing: bit-level, instruction-level, data, and task parallelism. Parallelism has been employed for many years, mainly in high-performance computing, but interest in it has grown lately due to the physical constraints preventing frequency scaling.' ); " \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH) "  \
				"VALUES (2, 'As power consumption (and consequently heat generation) by computers has become a concern in recent years, parallel computing has become the dominant paradigm in computer architecture, mainly in the form of multi-core processors' ); "     \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (3, 'Parallel computing is closely related to concurrent computing�they are frequently used together, and often conflated, though the two are distinct: it is possible to have parallelism without concurrency (such as bit-level parallelism), and concurrency without parallelism (such as multitasking by time-sharing on a single-core CPU).' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (4, 'In parallel computing, a computational task is typically broken down in several, often many, very similar subtasks that can be processed independently and whose results are combined afterwards, upon completion.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (5, ' In contrast, in concurrent computing, the various processes often do not address related tasks; when they do, as is typical in distributed computing, the separate tasks may have a varied nature and often require some inter-process communication during execution.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (6, 'Parallel computers can be roughly classified according to the level at which the hardware supports parallelism, with multi-core and multi-processor computers having multiple processing elements within a single machine, while clusters, MPPs, and grids use multiple computers to work on the same task. Specialized parallel computer architectures are sometimes used alongside traditional processors, for accelerating specific tasks.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (7, 'In some cases parallelism is transparent to the programmer, such as in bit-level or instruction-level parallelism, but explicitly parallel algorithms, particularly those that use concurrency, are more difficult to write than sequential ones,' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (8, 'because concurrency introduces several new classes of potential software bugs, of which race conditions are the most common. Communication and synchronization between the different subtasks are typically some of the greatest obstacles to getting good parallel program performance.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (9, 'Traditionally, computer software has been written for serial computation. To solve a problem, an algorithm is constructed and implemented as a serial stream of instructions. These instructions are executed on a central processing unit on one computer. Only one instruction may execute at a time�after that instruction is finished, the next one is executed' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (10, 'Parallel computing, on the other hand, uses multiple processing elements simultaneously to solve a problem. This is accomplished by breaking the problem into independent parts so that each processing element can execute its part of the algorithm simultaneously with the others. ' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (11, 'The processing elements can be diverse and include resources such as a single computer with multiple processors, several networked computers, specialized hardware, or any combination of the above.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (12, 'Frequency scaling was the dominant reason for improvements in computer performance from the mid-1980s until 2004. The runtime of a program is equal to the number of instructions multiplied by the average time per instruction. Maintaining everything else constant, increasing the clock frequency decreases the average time it takes to execute an instruction. An increase in frequency thus decreases runtime for all compute-bound programs.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (13, 'Moores law is the empirical observation that the number of transistors in a microprocessor doubles every 18 to 24 months.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (14, 'Despite power consumption issues, and repeated predictions of its end, Moores law is still in effect. With the end of frequency scaling, these additional transistors (which are no longer used for frequency scaling) can be used to add extra hardware for parallel computing.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (15, 'Optimally, the speedup from parallelization would be linear�doubling the number of processing elements should halve the runtime, and doubling it a second time should again halve the runtime. However, very few parallel algorithms achieve optimal speedup. ' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (16, 'Most of them have a near-linear speedup for small numbers of processing elements, which flattens out into a constant value for large numbers of processing elements.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (17, 'Amdahls law only applies to cases where the problem size is fixed. In practice, as more computing resources become available, they tend to get used on larger problems (larger datasets), and the time spent in the parallelizable part often grows much faster than the inherently serial work' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (18, 'Both Amdahls law and Gustafsons law assume that the running time of the serial part of the program is independent of the number of processors. Amdahls law assumes that the entire problem is of fixed size so that the total amount of work to be done in parallel is also independent of the number of processors, whereas Gustafsons law assumes that the total amount of work to be done in parallel varies linearly with the number of processors.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (19, 'Understanding data dependencies is fundamental in implementing parallel algorithms. No program can run more quickly than the longest chain of dependent calculations (known as the critical path), since calculations that depend upon prior calculations in the chain must be executed in order.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (20, 'However, most algorithms do not consist of just a long chain of dependent calculations; there are usually opportunities to execute independent calculations in parallel.' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (21, 'Violation of the first condition introduces a flow dependency, corresponding to the first segment producing a result used by the second segment. The second condition represents an anti-dependency, when the second segment produces a variable needed by the first segment. ' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (22, 'Subtasks in a parallel program are often called threads. Some parallel computer architectures use smaller, lightweight versions of threads known as fibers, while others use bigger versions known as processes. However, If instruction 1B is executed between 1A and 3A, or if instruction 1A is executed between 1B and 3B, the program will produce incorrect data. This is known as a race condition. The programmer must use a lock to provide mutual exclusion. A lock is a programming language construct that allows one thread to take control of a variable and prevent other threads from reading or writing it, until that variable is unlocked. The thread holding the lock is free to execute its critical section (the section of a program that requires exclusive access to some variable), and to unlock the data when it is finished.threads is generally accepted as a generic term for subtasks. Threads will often need to update some variable that is shared between them. ' );" \
				"INSERT INTO TEXT_TO_BE_SEARCHED (ID,TEXT_TO_SEARCH)" \
				"VALUES (23, 'One thread will successfully lock variable V, while the other thread will be locked out�unable to proceed until V is unlocked again. This guarantees correct execution of the program. Locks, while necessary to ensure correct program execution, can greatly slow a program.' );";

			/* Execute INSERT SQL */
			rc = sqlite3_exec(db, insertSql, callback, 0, &zErrMsg);
			if (rc != SQLITE_OK) {
				fprintf(stderr, "SQL error: %s\n", zErrMsg);
				sqlite3_free(zErrMsg);
			}
			else {
				fprintf(stdout, "Records created successfully\n");
			}
		}
		else
		{
			printf("TEXT_TO_BE_SEARCHED already exists. \n");
		}

	}
	else
	{
		cout << "Failed to open db\n";
	}

	/* SELECT SQL*/
	selectSql = "SELECT * from TEXT_TO_BE_SEARCHED";

	/* Execute SELECT SQL statement */
	rc = sqlite3_exec(db, selectSql, callback, (void*)data, &zErrMsg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", zErrMsg);
		sqlite3_free(zErrMsg);
	}
	else {
		fprintf(stdout, "Operation done successfully. Data selected from table.\n");
	}

	//Create the size of the vectors as you know number of columns (this case two due to the select ID,TEXT_TO_SEARCH). Need to set the same number below or you will get NULL exception
	for (int i = 0; i < 2; i++)
		resultSearch.push_back(std::vector< std::string >());

	//int sqlite3_prepare(
	//	sqlite3 *db,            /* Database handle */
	//	const char *zSql,       /* SQL statement, UTF-8 encoded */
	//	int nByte,              /* Maximum length of zSql in bytes. */
	//	sqlite3_stmt **ppStmt,  /* OUT: Statement handle */
	//	const char **pzTail     /* OUT: Pointer to unused portion of zSql */
	//);

	getAllRecords = "select ID,TEXT_TO_SEARCH from TEXT_TO_BE_SEARCHED;";
	sqlite3_prepare(db, getAllRecords, -1, &stmtSearch, NULL);//preparing the statement, see the parameters above.
	sqlite3_step(stmtSearch); //executing the statement

	while (sqlite3_column_text(stmtSearch, 0))
	{
		//Loop through the results and store them, 1 due to the fact that ther is 1 column. 
		//You will always know the number of columns but not rows.
		//Add the results to the array of of vectors resultSearch indexing at 0 (to put back need to add one to i, this will get the ID.)
		for (int i = 0; i < 2; i++)
			resultSearch[i].push_back(std::string((char *)sqlite3_column_text(stmtSearch, i)));
		sqlite3_step(stmtSearch);
	}

	//Close database connection
	sqlite3_close(db);


	int numberOfRows = resultSearch[1].size();
	//Could be made into a non-hardcoded value, need the number of rows.
	int *isPresent = new int[numberOfRows];

	printf("Matching given word/ phrase with data... \n");
	//Loop through each piece of text and find if there is a matching string to that defined.
	//Write 1 if so or 0 if not.
	for (int j = 0; j < numberOfRows; j++)
	{
		textToBeSearched = resultSearch[1][j];
		size_t found = textToBeSearched.find(textToFind);
		if (found != std::string::npos)
		{
			isPresent[j] = 1;
			printf("Match found! \n");
		}
		else
		{
			isPresent[j] = 0;
			printf("Match not found! \n");
		}
	}

	printf("The isPresent array is (1 = match 0 = no match): \n");
	for (int a = 0; a < numberOfRows; a++)
	{
		cout << isPresent[a] << '\n';
	}


	if (sqlite3_open("SOFT354Coursework.db", &db) == SQLITE_OK)
	{
		printf("Updating table with matching values to show if word/ phrases is present or not... \n");
		for (int i = 0; i < numberOfRows; i++)
		{
			//Need to add 1 as the array is indexed at 0 but the table is indexed at 1 for IDs
			idToUpdate = i + 1;

			if (isPresent[i] == 1)
			{
				updateIsPresentColumn = "UPDATE TEXT_TO_BE_SEARCHED SET IS_PRESENT = 1 WHERE ID = ?";
				rc = sqlite3_prepare(db, updateIsPresentColumn, -1, &stmtUpdate, NULL);//preparing the statement
				if (rc == SQLITE_OK) { //Ensure SQL query is valid

					sqlite3_bind_int(stmtUpdate, 1, idToUpdate); //Set the ? values are (stmt, questionMarkNumber, valueToAdd)
				}
				else {

					fprintf(stderr, "Failed to execute statement: %s\n", sqlite3_errmsg(db)); //Print if there is an error with the prepared statment 
				}
				sqlite3_step(stmtUpdate); //executing the statement
				sqlite3_finalize(stmtUpdate); //Clear the stmtUpdate
			}
			else if (isPresent[i] == 0)
			{
				updateIsPresentColumn = "UPDATE TEXT_TO_BE_SEARCHED SET IS_PRESENT = 0 WHERE ID = ?";
				sqlite3_prepare(db, updateIsPresentColumn, -1, &stmtUpdate, NULL);//preparing the statement
				if (rc == SQLITE_OK) { //Ensure SQL query is valid

					sqlite3_bind_int(stmtUpdate, 1, idToUpdate); //Set the ? values are (stmt, questionMarkNumber, valueToAdd)
				}
				else {

					fprintf(stderr, "Failed to execute statement: %s\n", sqlite3_errmsg(db)); //Print if there is an error with the prepared statment 
				}
				sqlite3_step(stmtUpdate); //executing the statement
				sqlite3_finalize(stmtUpdate); //Clear the stmtUpdate
			}
			else
			{
				printf("Value of isPresent array is neither a 1 or 0, check results and the matching process. Likely issue is that data that was inserted has charcters which need escaped. \n");
			}
		}
	}
	else
	{
		cout << "Failed to open db \n";
	}

	/* SELECT SQL*/
	selectSql = "SELECT * from TEXT_TO_BE_SEARCHED";

	/* Execute SELECT SQL statement */
	rc = sqlite3_exec(db, selectSql, callback, (void*)data, &zErrMsg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", zErrMsg);
		sqlite3_free(zErrMsg);
	}
	else {
		fprintf(stdout, "Operation done successfully, selected data with updated is_present field \n");
	}

	///* DROP TABLE SQL*/
	//selectSql = "DROP TABLE TEXT_TO_BE_SEARCHED";

	///* Execute DELETE SQL statement */
	//rc = sqlite3_exec(db, selectSql, callback, (void*)data, &zErrMsg);
	//if (rc != SQLITE_OK) {
	//	fprintf(stderr, "SQL error: %s\n", zErrMsg);
	//	sqlite3_free(zErrMsg);
	//}
	//else {
	//	fprintf(stdout, "Operation done successfully, TEXT_TO_BE_SEARCHED has been dropped \n");
	//}

	//Close database connection
	sqlite3_close(db);
	//Free space from isPresent array as it is dynamically allocated
	delete[] isPresent;
	return 0;
}

