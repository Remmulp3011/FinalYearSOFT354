#include "stdio.h"
#include <cstring>
#include "mpi.h"
#include "stdlib.h"
#include "math.h"

int main()
{
	int commSize;
	int myRank;

	MPI_Init(NULL, NULL);

	MPI_Comm_size(MPI_COMM_WORLD, &commSize);
	MPI_Comm_rank(MPI_COMM_WORLD, &myRank);

	if (myRank == 0)
	{
		while (true)
		{
			//further exercise 
			float val = (float)rand() / RAND_MAX;
			MPI_Send(&val, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD);

			//normal exercise
			char msg[128];
			MPI_Status msgStatus;
			MPI_Recv(msg, sizeof(msg), MPI_CHAR, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &msgStatus);
			printf("Received the following message from %d: '%s '\n", msgStatus.MPI_SOURCE, msg);
			fflush(stdout);
		}
	}
	else
	{
		//further exercise
		sin(myRank);

		//normal excercise
		char msg[128];
		sprintf_s(msg, sizeof(msg), "Hello from process %d!", myRank);
		MPI_Send(msg, strlen(msg) + 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
	}

	printf("Hello from process %d of %d!\n", myRank, commSize);

	MPI_Finalize();

	return 0;
}