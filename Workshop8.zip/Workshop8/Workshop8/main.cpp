#include <mpi.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <utility>
#include <map>
#include <vector>
#include <sstream>

const int NUM_KEYS = 26;
float keyDistances[NUM_KEYS*NUM_KEYS];
const int MAX_WORD_SIZE = 32;

// Function prototypes (see bottom of file for actual functions).
void loadTextFile(const char* path, char** outArray, long* outSize);
int findClosestWord(char* typoWord, char* wordList, int wordListLength);
void calculateKeyDistances();
void parseWordFile(char* contents, long contentsLen, char** wordsOut, int* numWordsOut);

int main()
{
	MPI_Init(NULL, NULL);

	// Arrays (not yet allocated) to store the complete word list,
	// and the list of words with typos in.
	char* allWords = NULL;
	int numAllWords;
	char* typoWords = NULL;
	int numTypoWords;



	int processRank;
	int processSize;
	
	MPI_Comm_size(MPI_COMM_WORLD, &processSize);
	MPI_Comm_rank(MPI_COMM_WORLD, &processRank);

	// This function generates a global array called 'keyDistances' that
	// stores the distance between different characters on the keyboard.
	calculateKeyDistances();

	// Load the word lists from disk.
	char* fileContents;
	long fileSize;

	if (processRank == 0)
	{
		// Load words.txt into 'allWords' array. The number of words loaded
		// is stored in numAllWords.
		loadTextFile("words.txt", &fileContents, &fileSize);
		parseWordFile(fileContents, fileSize, &allWords, &numAllWords);
		delete fileContents;

		// Load typos.txt in 'typoWords' array. The number of words loaded
		// is stored in numTypoWords.
		loadTextFile("typos.txt", &fileContents, &fileSize);
		parseWordFile(fileContents, fileSize, &typoWords, &numTypoWords);
		delete fileContents;
		fileContents = NULL;
	}

	MPI_Bcast(&numAllWords, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&numTypoWords, 1, MPI_INT, 0, MPI_COMM_WORLD);
	
	if (processRank != 0)
	{
		allWords = new char[numAllWords*MAX_WORD_SIZE];
		typoWords = new char[numTypoWords*MAX_WORD_SIZE];
	}

	MPI_Bcast(allWords, numAllWords*MAX_WORD_SIZE, MPI_CHAR, 0, MPI_COMM_WORLD);
	MPI_Bcast(typoWords, numTypoWords*MAX_WORD_SIZE, MPI_CHAR, 0, MPI_COMM_WORLD);
	

	int wordsToProcessEach = numTypoWords / processSize;
	int firstIndex = processRank * wordsToProcessEach;
	int lastIndex = ((processRank + 1) * wordsToProcessEach) - 1;

	// Iterate through all the typos that this process should work on.
	for (int i = firstIndex; i <= lastIndex; i++) {
		// Find the index of the closest matching word in allWords.
		int correctedIdx = findClosestWord(typoWords + i*MAX_WORD_SIZE, allWords, numAllWords);

		if (i != lastIndex) continue; // Skip printing for all except the last word.

		printf("%s -> %s\n Processes rank = %d", typoWords + i*MAX_WORD_SIZE, allWords + correctedIdx*MAX_WORD_SIZE, processRank);
	}
	MPI_Finalize();
	return 0;
}

////
// findClosestWord
// Returns the index of the word in 'wordList' that most closely matches
// the 'typoWord' argument. The closeness of a match is based on how near
// the letters on the keyboard are.
////
int findClosestWord(char* typoWord, char* wordList, int wordListLength)
{
	int closestIndex = -1;
	float closestDistance;
	for (int i = 0; i < wordListLength; i++) {
		// Only consider words that are the same length as the typo word.
		if (strlen(wordList + i*MAX_WORD_SIZE) == strlen(typoWord)) {
			// Iterate through each character of the candidate word, calculating
			// how far away on the keyboard it is from the character in the same
			// position in the typo word.
			float distance = 0.0f;
			for (unsigned int j = 0; j < strlen(wordList + i*MAX_WORD_SIZE); j++) {
				if (wordList[i*MAX_WORD_SIZE + j] >= 'a' && wordList[i*MAX_WORD_SIZE + j] <= 'z') {
					distance += keyDistances[(wordList[i*MAX_WORD_SIZE + j] - 'a')*NUM_KEYS + typoWord[j] - 'a'];
				}
			}
			// Do we have a new better match?
			if (closestIndex == -1 || distance < closestDistance) {
				closestDistance = distance;
				closestIndex = i;
			}
		}
	}

	// Return index of the closest match.
	return closestIndex;
}

////
// loadTextFile
// This function loads a  text file into an array. The array is allocated
// inside the function, and its address stored in 'outArray'.
////
void loadTextFile(const char* path, char** outArray, long* outSize)
{
	FILE* wordFile;
	fopen_s(&wordFile, path, "rb");
	fseek(wordFile, 0, SEEK_END);
	*outSize = ftell(wordFile) + 1;
	rewind(wordFile);

	char* data = new char[*outSize];
	fread(data, 1, (*outSize) - 1, wordFile);
	fclose(wordFile);
	data[(*outSize) - 1] = NULL;

	*outArray = data;
}

////
// parseWordFile
// This function takes an array of characters containing the contents of a word list file
// and splits it into words that are separated by newlines. A new array is allocated (wordsOut)
// to hold the list of loaded words, and the number of words that were loaded is stored in the
// numWordsOut output parameter.
////
void parseWordFile(char* contents, long contentsLen, char** wordsOut, int* numWordsOut)
{
	// Count the number of words by counting newlines.
	*numWordsOut = 1; // Start at 1 as last line has no \n.
	for (long i = 0; i < contentsLen; i++) {
		if (contents[i] == '\n') (*numWordsOut)++;
	}

	// Allocate array to hold the words.
	*wordsOut = new char[MAX_WORD_SIZE*(*numWordsOut)];

	// Split on \n using istringstream.
	std::istringstream iss(contents);
	std::string word;
	for (int i = 0; i < *numWordsOut; i++) {
		iss >> word;
		strncpy_s(*wordsOut + i*MAX_WORD_SIZE, MAX_WORD_SIZE, word.c_str(), _TRUNCATE);
	}
}

////
// calculateKeyDistances
// This function generates the 2D 'keyDistances' array. This array contains, for every pair
// of letters, their distance from each other on the keyboard. Could get away with just
// calculating/storing half these values, since the distances are symmetric, but I'm lazy.
////
void calculateKeyDistances()
{
	// Define the rows of letters on the keyboard.
	std::vector<const char *> keyboardRows;
	keyboardRows.push_back("qwertyuiop");
	keyboardRows.push_back("asdfghjkl");
	keyboardRows.push_back("zxcvbnm");

	// Build a map that maps each letter (a-z) to its x,y position on the keyboard.
	std::map<char, std::pair<int, int>> keyPositions;
	for (unsigned int row = 0; row < keyboardRows.size(); row++) {
		unsigned int col = 0;
		for (; keyboardRows[row][col] != 0; col++){
			keyPositions[keyboardRows[row][col]] = std::pair<int, int>(row, col);
		}
	}

	// For every pair of characters, calculate their distance and store this in the
	// keyDistances array.
	for (char c1 = 'a'; c1 <= 'z'; c1++) {
		for (char c2 = 'a'; c2 <= 'z'; c2++) {
			float dx = (float)(keyPositions[c1].first - keyPositions[c2].first);
			float dy = (float)(keyPositions[c1].second - keyPositions[c2].second);
			keyDistances[(c1 - 'a')*NUM_KEYS + c2 - 'a'] = sqrt(dx*dx + dy*dy); // Don't need sqrt, but whatever...
		}
	}
}
